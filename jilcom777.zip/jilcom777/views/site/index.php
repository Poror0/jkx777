<?php

$this->title = 'ЖКХ777';
?>
<div class="site-index">

    <div class="jumbotron text-center bg-transparent mt-5 mb-5">
        <h1 class="display-4">Добро пожаловать в ЖКХ777!</h1>

        <p class="lead">Система управления заявками по решению проблем жильцов</p>

        <?php if (Yii::$app->user->isGuest): ?>
            <p>
                <a class="btn btn-lg btn-success" href="<?= \yii\helpers\Url::to(['/site/register']) ?>">Регистрация</a>
                <a class="btn btn-lg btn-primary" href="<?= \yii\helpers\Url::to(['/site/login']) ?>">Вход</a>
            </p>
        <?php else: ?>
            <p>
                <?php if (Yii::$app->user->identity->is_admin): ?>
                    <a class="btn btn-lg btn-primary" href="<?= \yii\helpers\Url::to(['/admin/application/index']) ?>">Панель администратора</a>
                <?php else: ?>
                    <a class="btn btn-lg btn-primary" href="<?= \yii\helpers\Url::to(['/account/application/index']) ?>">Мои заявки</a>
                    <a class="btn btn-lg btn-success" href="<?= \yii\helpers\Url::to(['/account/application/create']) ?>">Создать заявку</a>
                <?php endif; ?>
            </p>
        <?php endif; ?>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4 mb-3">
                <h2>Быстро</h2>
                <p>Создайте заявку на вызов специалиста за несколько минут. Укажите проблему, выберите специалиста и отправьте заявку.</p>
            </div>
            <div class="col-lg-4 mb-3">
                <h2>Удобно</h2>
                <p>Отслеживайте статус своих заявок в личном кабинете. Получайте уведомления об изменении статуса.</p>
            </div>
            <div class="col-lg-4">
                <h2>Надежно</h2>
                <p>Все заявки обрабатываются администратором. Вы можете быть уверены, что ваша проблема будет решена.</p>
            </div>
        </div>

    </div>
</div>
