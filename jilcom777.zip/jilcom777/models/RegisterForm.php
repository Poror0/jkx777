<?php

namespace app\models;

use Yii;
use yii\base\Model;

class RegisterForm extends Model
{
    public $full_name;
    public $username;
    public $email;
    public $phone;
    public $address;
    public $password;

    public function rules()
    {
        return [
            [['full_name', 'username', 'email', 'phone', 'address', 'password'], 'required'],
            ['full_name', 'match', 'pattern' => '/^[а-яёА-ЯЁ\s\-]+$/u', 'message' => 'ФИО должно содержать только кириллические буквы, дефис и пробелы'],
            ['username', 'match', 'pattern' => '/^[a-zA-Z\-]+$/', 'message' => 'Логин должен содержать только латинские буквы и дефис'],
            ['username', 'unique', 'targetClass' => User::class, 'message' => 'Этот логин уже занят'],
            ['email', 'email', 'message' => 'Некорректный формат email'],
            ['email', 'unique', 'targetClass' => User::class, 'message' => 'Этот email уже зарегистрирован'],
            ['phone', 'match', 'pattern' => '/^\+7\d{10}$/', 'message' => 'Телефон должен быть в формате +7XXXXXXXXXX (11 цифр)'],
            ['password', 'string', 'min' => 8, 'message' => 'Пароль должен содержать минимум 8 символов'],
            ['password', 'match', 'pattern' => '/^(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', 'message' => 'Пароль должен содержать минимум 1 большую букву и 1 цифру, только латиница'],
            ['address', 'string'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'full_name' => 'ФИО',
            'username' => 'Логин',
            'email' => 'Email',
            'phone' => 'Телефон',
            'address' => 'Адрес проживания',
            'password' => 'Пароль',
        ];
    }

    public function register()
    {
        if (!$this->validate()) {
            return null;
        }

        $user = new User();
        $user->full_name = $this->full_name;
        $user->username = $this->username;
        $user->email = $this->email;
        $user->phone = $this->phone;
        $user->address = $this->address;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        $user->is_admin = false;

        return $user->save() ? $user : null;
    }
}
