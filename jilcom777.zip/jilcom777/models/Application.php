<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;

class Application extends ActiveRecord
{
    const STATUS_NEW = 'new';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_IN_PROGRESS = 'in_progress';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    public static function tableName()
    {
        return 'application';
    }

    public function behaviors()
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function rules()
    {
        return [
            [['user_id', 'profession_id', 'title', 'description'], 'required'],
            [['user_id', 'profession_id'], 'integer'],
            [['description', 'rejection_reason'], 'string'],
            [['created_at', 'updated_at'], 'integer'],
            [['title'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 50],
            [['status'], 'in', 'range' => [self::STATUS_NEW, self::STATUS_CONFIRMED, self::STATUS_IN_PROGRESS, self::STATUS_COMPLETED, self::STATUS_CANCELLED]],
            [['profession_id'], 'exist', 'skipOnError' => true, 'targetClass' => Profession::class, 'targetAttribute' => ['profession_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'Пользователь',
            'profession_id' => 'Специалист',
            'title' => 'Наименование заявки',
            'description' => 'Описание проблемы',
            'status' => 'Статус',
            'rejection_reason' => 'Причина отклонения',
            'created_at' => 'Дата создания',
            'updated_at' => 'Дата обновления',
        ];
    }

    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }

    public function getProfession()
    {
        return $this->hasOne(Profession::class, ['id' => 'profession_id']);
    }

    public function getStatusLabel()
    {
        $statuses = [
            self::STATUS_NEW => 'Новая',
            self::STATUS_CONFIRMED => 'Подтверждено',
            self::STATUS_IN_PROGRESS => 'В работе',
            self::STATUS_COMPLETED => 'Выполнено',
            self::STATUS_CANCELLED => 'Отменено',
        ];
        return $statuses[$this->status] ?? $this->status;
    }

    public static function getStatusList()
    {
        return [
            self::STATUS_NEW => 'Новая',
            self::STATUS_CONFIRMED => 'Подтверждено',
            self::STATUS_IN_PROGRESS => 'В работе',
            self::STATUS_COMPLETED => 'Выполнено',
            self::STATUS_CANCELLED => 'Отменено',
        ];
    }
}
