<?php

namespace app\models;

use yii\db\ActiveRecord;

class Profession extends ActiveRecord
{
    public static function tableName()
    {
        return 'profession';
    }

    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название',
        ];
    }

    public function getApplications()
    {
        return $this->hasMany(Application::class, ['profession_id' => 'id']);
    }
}
