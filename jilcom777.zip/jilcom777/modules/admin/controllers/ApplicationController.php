<?php

namespace app\modules\admin\controllers;

use Yii;
use app\models\Application;
use app\models\Profession;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

class ApplicationController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $applications = Application::find()
            ->with(['user', 'profession'])
            ->orderBy(['created_at' => SORT_DESC])
            ->all();

        return $this->render('index', [
            'applications' => $applications,
        ]);
    }

    public function actionView($id)
    {
        $model = $this->findModel($id);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {
            if ($model->status === Application::STATUS_CANCELLED && empty($model->rejection_reason)) {
                $model->addError('rejection_reason', 'Укажите причину отклонения');
            } else {
                if ($model->save()) {
                    Yii::$app->session->setFlash('success', 'Заявка успешно обновлена');
                    return $this->redirect(['view', 'id' => $model->id]);
                }
            }
        }

        $professions = Profession::find()->select(['name', 'id'])->indexBy('id')->column();

        return $this->render('update', [
            'model' => $model,
            'professions' => $professions,
        ]);
    }

    protected function findModel($id)
    {
        if (($model = Application::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Заявка не найдена');
    }
}
