<?php

use yii\bootstrap5\Html;
use yii\bootstrap5\ActiveForm;
use app\models\Application;

?>

<div class="application-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true, 'readonly' => true]) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6, 'readonly' => true]) ?>

    <?= $form->field($model, 'profession_id')->dropDownList($professions, ['disabled' => true]) ?>

    <?= $form->field($model, 'status')->dropDownList(Application::getStatusList()) ?>

    <?= $form->field($model, 'rejection_reason')->textarea(['rows' => 3, 'placeholder' => 'Обязательно для статуса "Отменено"']) ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
