<?php

use yii\bootstrap5\Html;
use yii\widgets\DetailView;

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Все заявки', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Изменить статус', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Назад к списку', ['index'], ['class' => 'btn btn-secondary']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'attribute' => 'user_id',
                'value' => $model->user->full_name,
                'label' => 'Заявитель',
            ],
            [
                'label' => 'Телефон',
                'value' => $model->user->phone,
            ],
            [
                'label' => 'Email',
                'value' => $model->user->email,
            ],
            [
                'label' => 'Адрес',
                'value' => $model->user->address,
            ],
            'title',
            'description:ntext',
            [
                'attribute' => 'profession_id',
                'value' => $model->profession->name,
            ],
            [
                'attribute' => 'status',
                'value' => $model->getStatusLabel(),
            ],
            'rejection_reason:ntext',
            'created_at:datetime',
            'updated_at:datetime',
        ],
    ]) ?>

</div>
