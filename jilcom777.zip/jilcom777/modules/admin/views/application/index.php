<?php

use yii\bootstrap5\Html;

$this->title = 'Все заявки';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row">
        <?php if (empty($applications)): ?>
            <div class="col-12">
                <p>Заявок пока нет</p>
            </div>
        <?php else: ?>
            <?php foreach ($applications as $application): ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= Html::encode($application->title) ?></h5>
                            <p class="card-text">
                                <strong>Заявитель:</strong> <?= Html::encode($application->user->full_name) ?><br>
                                <strong>Телефон:</strong> <?= Html::encode($application->user->phone) ?><br>
                                <strong>Email:</strong> <?= Html::encode($application->user->email) ?><br>
                                <strong>Адрес:</strong> <?= Html::encode($application->user->address) ?><br>
                                <strong>Специалист:</strong> <?= Html::encode($application->profession->name) ?><br>
                                <strong>Статус:</strong> <span class="badge bg-info"><?= Html::encode($application->getStatusLabel()) ?></span><br>
                                <strong>Дата:</strong> <?= Yii::$app->formatter->asDatetime($application->created_at) ?>
                            </p>
                            <?= Html::a('Просмотр', ['view', 'id' => $application->id], ['class' => 'btn btn-primary btn-sm']) ?>
                            <?= Html::a('Изменить статус', ['update', 'id' => $application->id], ['class' => 'btn btn-warning btn-sm']) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
