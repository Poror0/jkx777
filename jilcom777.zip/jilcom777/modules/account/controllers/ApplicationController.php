<?php

namespace app\modules\account\controllers;

use Yii;
use app\models\Application;
use app\models\Profession;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\ForbiddenHttpException;

class ApplicationController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['POST'],
                    'cancel' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $applications = Application::find()
            ->where(['user_id' => Yii::$app->user->id])
            ->orderBy(['created_at' => SORT_DESC])
            ->all();

        return $this->render('index', [
            'applications' => $applications,
        ]);
    }

    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess($model);

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionCreate()
    {
        $model = new Application();
        $model->user_id = Yii::$app->user->id;
        $model->status = Application::STATUS_NEW;

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка успешно создана');
            return $this->redirect(['view', 'id' => $model->id]);
        }

        $professions = Profession::find()->select(['name', 'id'])->indexBy('id')->column();

        return $this->render('create', [
            'model' => $model,
            'professions' => $professions,
        ]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess($model);

        if ($model->status !== Application::STATUS_NEW) {
            Yii::$app->session->setFlash('error', 'Можно редактировать только новые заявки');
            return $this->redirect(['view', 'id' => $model->id]);
        }

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка успешно обновлена');
            return $this->redirect(['view', 'id' => $model->id]);
        }

        $professions = Profession::find()->select(['name', 'id'])->indexBy('id')->column();

        return $this->render('update', [
            'model' => $model,
            'professions' => $professions,
        ]);
    }

    public function actionCancel($id)
    {
        $model = $this->findModel($id);
        $this->checkAccess($model);

        if ($model->status === Application::STATUS_NEW || $model->status === Application::STATUS_CONFIRMED) {
            $model->status = Application::STATUS_CANCELLED;
            $model->rejection_reason = 'Отменено пользователем';
            if ($model->save()) {
                Yii::$app->session->setFlash('success', 'Заявка отменена');
            }
        } else {
            Yii::$app->session->setFlash('error', 'Невозможно отменить заявку с текущим статусом');
        }

        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = Application::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Заявка не найдена');
    }

    protected function checkAccess($model)
    {
        if ($model->user_id !== Yii::$app->user->id) {
            throw new ForbiddenHttpException('У вас нет доступа к этой заявке');
        }
    }
}
