<?php

use yii\bootstrap5\Html;

$this->title = 'Мои заявки';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Создать заявку', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <div class="row">
        <?php if (empty($applications)): ?>
            <div class="col-12">
                <p>У вас пока нет заявок</p>
            </div>
        <?php else: ?>
            <?php foreach ($applications as $application): ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= Html::encode($application->title) ?></h5>
                            <p class="card-text">
                                <strong>Специалист:</strong> <?= Html::encode($application->profession->name) ?><br>
                                <strong>Статус:</strong> <span class="badge bg-info"><?= Html::encode($application->getStatusLabel()) ?></span><br>
                                <strong>Дата:</strong> <?= Yii::$app->formatter->asDatetime($application->created_at) ?>
                            </p>
                            <?= Html::a('Просмотр', ['view', 'id' => $application->id], ['class' => 'btn btn-primary btn-sm']) ?>
                            <?php if ($application->status === \app\models\Application::STATUS_NEW || $application->status === \app\models\Application::STATUS_CONFIRMED): ?>
                                <?= Html::a('Отменить', ['cancel', 'id' => $application->id], [
                                    'class' => 'btn btn-danger btn-sm',
                                    'data' => [
                                        'confirm' => 'Вы уверены, что хотите отменить эту заявку?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
