<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=zhkh777',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
